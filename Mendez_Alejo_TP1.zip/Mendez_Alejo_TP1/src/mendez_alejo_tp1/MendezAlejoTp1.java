
package mendez_alejo_tp1;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Alejo Mendez
 */
public class MendezAlejoTp1 {

    
    public static void main(String[] args) {
        
        conversorDeUnidadesDeAlmacenamiento();
        
    } //cierre del main
    
   
    //Procedimiento que llama a las distintas funciones y procedimientos, junto con la clase Scanner.
    //Declaro el vector tipoDeUnidadDeAlmacenamiento y le asigno como valor
    //las unidades de almacenamiento que acepta el programa.
    //Declaro un vector de double y asigno el valor equivalente en bits 
    //a 1 unidad de cada tipo de las unidades de almacenamiento respectivamente, 
    //es decir 1 bit = 1.0 bit, 1 bit = 8.0 bytes, 1 bit = 8192.0 kilobytes y así sucesivamente.
    public static void conversorDeUnidadesDeAlmacenamiento(){
        Scanner teclado = new Scanner(System.in);
        String[] tipoDeUnidadDeAlmacenamiento = {"bit", "byte", "kilobyte", "megabyte", "gigabyte", "terabyte"};  
        double [] valoresEquivalentesEnBit = {1.0, 8.0, 8192.0, 8388608.0, 8589934592.0, 8796093022208.0};
        mostrarEncabezado();
        ingresarUnidadYComprobar(tipoDeUnidadDeAlmacenamiento, teclado, valoresEquivalentesEnBit);
    }
    
    //Este procedimiento imprime por pantalla el siguiente mensaje al iniciar el programa.
    public static void mostrarEncabezado(){
        System.out.println("**********************************************");
        System.out.println("***CONVERSOR DE UNIDADES DE ALMACENAMIENTO****");
        System.out.println("**********************************************");
        System.out.println("Para utilizar este programa, primero debe elegir la unidad que desea convertir.\n" +
                "**********************************************");
    }
    
    /**
     *este procedimiento muestra las opciones (llamando al procedimiento mostrarOpciones) 
      y permite al usuario elegir entre una de las unidades de almacenamiento,
      escribiendo el nombre de la unidad (almacenándola en el String unidadSeleccionada),
      para luego imprimirla por pantalla.
      En caso de que la unidad ingresada no coincida con el nombre de alguna de las unidades,
      se imprimirá un mensaje de error y volverá a repetir la secuencia.
      Si se encuentra coincidencia, se llamará al procedimiento correspondiente con la unidad seleccionada
      para realizar la conversión, el cual a su vez llama a la función que retorna el valor ingresado
      para finalmente mostrar por pantalla los resultados de la conversión.
     * @param tiposDeUnidad
     * @param teclado 
     */
    
    public static void ingresarUnidadYComprobar(String[] tiposDeUnidad, Scanner teclado, double [] valoresEquivalentes){
        boolean error = true;
        String unidadSeleccionada;
        while(error==true){
            mostrarOpciones();
            System.out.println("Por favor escriba el nombre de la unidad deseada:");
            unidadSeleccionada=teclado.next().toLowerCase();
            
            for (int i=0; i<tiposDeUnidad.length; i++) {
                if(!unidadSeleccionada.equals(tiposDeUnidad[i]))continue;
       
                else if(unidadSeleccionada.equals(tiposDeUnidad[i])){
                    error=false;
                    System.out.println("Has elegido " + tiposDeUnidad[i]);
                    
                    if(unidadSeleccionada.equals(tiposDeUnidad[0])){
                        calcularValorBits(tiposDeUnidad, ingresarValorDeLaUnidad(teclado), valoresEquivalentes);
                    }
                    else if(unidadSeleccionada.equals(tiposDeUnidad[1])){
                        calcularValorBytes(tiposDeUnidad, ingresarValorDeLaUnidad(teclado), valoresEquivalentes);
                    }
                    else if(unidadSeleccionada.equals(tiposDeUnidad[2])){
                        calcularValorKiloBytes(tiposDeUnidad, ingresarValorDeLaUnidad(teclado), valoresEquivalentes);
                    }
                    else if(unidadSeleccionada.equals(tiposDeUnidad[3])){
                        calcularValorMegaBytes(tiposDeUnidad, ingresarValorDeLaUnidad(teclado), valoresEquivalentes);
                    }
                    else if(unidadSeleccionada.equals(tiposDeUnidad[4])){
                        calcularValorGigaBytes(tiposDeUnidad, ingresarValorDeLaUnidad(teclado), valoresEquivalentes);
                    }
                    else{
                        calcularValorTeraBytes(tiposDeUnidad, ingresarValorDeLaUnidad(teclado), valoresEquivalentes);
                    }
                } 
            }
            if(error==true){
                System.out.println("*********************************************");
                System.out.println("ERROR, debe escribir un tipo de unidad válida");
                System.out.println("*********************************************");
            }    
        }
    }
     
    //Este procedimiento imprime por pantalla los tipos de unidad de almacenamiento válidos.
    public static void mostrarOpciones(){
        System.out.println("**A continuación seleccione una de las siguientes unidades:**\n" +
               
                "-Bit-\n"+ 
                "-Byte-\n"+ 
                "-Kilobyte-\n"+ 
                "-Megabyte-\n"+ 
                "-Gigabyte-\n"+ 
                "-Terabyte-\n");
    }
    
    //Esta función pide al usuario que ingrese un valor, que si es mayor a 0, lo devuelve como double
    //con el nombre valorDeLaUnidad.
    public static double ingresarValorDeLaUnidad(Scanner teclado){
        double valorIngresado;
        do {
            System.out.println("**Ahora ingrese el valor de la unidad seleccionada:");
            valorIngresado=teclado.nextDouble();
            if(valorIngresado<=0){
                System.out.println("ERROR, el número ingresado debe ser mayor a 0");
            }
        } while(valorIngresado<=0);
        return valorIngresado;    
    }
    
    //procedimiento para calcular e imprimir por pantalla los valores de conversión con bit como unidad seleccionada
    public static void calcularValorBits(String[] tipoDeUnidad, double valorIngresado, double[] valoresEquivalentes){
        double[] valoresBits = new double[6];
        DecimalFormat df = new DecimalFormat("#.###############");//15 decimales
        for (int i=0; i<tipoDeUnidad.length; i++) {
            valoresBits[i]=valorIngresado/valoresEquivalentes[i];
            String resultadoRedondeado=df.format(valoresBits[i]);
            System.out.println("Valor en " + tipoDeUnidad[i] + " = " + resultadoRedondeado);
        }            
    }
    
    //este procedimiento realiza el cálculo para convertir a bits el valor de cada  en cualquier unidad
    //para luego convertir ese valor a Bytes e imprimirlo por pantalla.
    public static void calcularValorBytes(String[] tipoDeUnidad, double valorIngresado, double [] valoresEquivalentes){
        double[] valorEnBits = new double[6];
        double[] valorEnBytes=new double[6];
        DecimalFormat df = new DecimalFormat("#.###############");//15 decimales
        
        for (int i=0; i<valorEnBits.length; i++) {
            valorEnBits[i]=1/valoresEquivalentes[i];
            valorEnBytes[i]=valorEnBits[i]*valorIngresado*valoresEquivalentes[1];
            String resultadoRedondeado=df.format(valorEnBytes[i]);
            System.out.println("Valor en " + tipoDeUnidad[i] + " = " + resultadoRedondeado);
        }  
    }
    
    //este procedimiento realiza el calculo para convertir a bits el valor ingresado en cualquier unidad
    //para luego convertir ese valor a KiloBytes e imprimirlo por pantalla.
    public static void calcularValorKiloBytes(String[] tipoDeUnidad, double valor, double[] valoresEquivalentes ){
        double[] valorEnBits=new double[6];
        double[] valorEnKiloBytes=new double[6];
        DecimalFormat df = new DecimalFormat("#.###############");//15 decimales
        
        for (int i=0; i<valoresEquivalentes.length; i++) {
            valorEnBits[i]= 1/valoresEquivalentes[i];
            valorEnKiloBytes[i]=valorEnBits[i]*valor*valoresEquivalentes[2];
            String resultadoRedondeado=df.format(valorEnKiloBytes[i]);
            System.out.println("Valor en " + tipoDeUnidad[i] + " = " + resultadoRedondeado);
        }  
    }
    
    //este procedimiento realiza el calculo para convertir a bits el valor ingresado en cualquier unidad
    //para luego convertir ese valor a MegaBytes e imprimirlo por pantalla.
    public static void calcularValorMegaBytes(String[] tipoDeUnidad, double valor, double[] valoresEquivalentes){
        double[] valorEnBits=new double[6];
        double[] valorEnMegaBytes=new double[6];
        DecimalFormat df = new DecimalFormat("#.###############");//15 decimales
        
        for (int i=0; i<valoresEquivalentes.length; i++) {
            valorEnBits[i]= 1/valoresEquivalentes[i];
            valorEnMegaBytes[i]=valorEnBits[i]*valor*valoresEquivalentes[3];
            String resultadoRedondeado=df.format(valorEnMegaBytes[i]);
            System.out.println("Valor en " + tipoDeUnidad[i] + " = " + resultadoRedondeado);
        }
    }
    
    //este procedimiento realiza el calculo para convertir a bits el valor ingresado en cualquier unidad
    //para luego convertir ese valor a GigaBytes e imprimirlo por pantalla.
    public static void calcularValorGigaBytes(String[] tipoDeUnidad, double valor, double[] valoresEquivalentes){
        double[] valorEnBits=new double[6];
        double[] valorEnGigaBytes=new double[6];
        DecimalFormat df = new DecimalFormat("#.###############");//15 decimales
        
        for (int i=0; i<valoresEquivalentes.length; i++) {
            valorEnBits[i]= 1/valoresEquivalentes[i];
            valorEnGigaBytes[i]=valorEnBits[i]*valor*valoresEquivalentes[4];
            String resultadoRedondeado=df.format(valorEnGigaBytes[i]);
            System.out.println("Valor en " + tipoDeUnidad[i] + " = " + resultadoRedondeado);
        }      
    }
    
    //este procedimiento realiza el calculo para convertir a bits el valor ingresado en cualquier unidad
    //para luego convertir ese valor a TeraBytes e imprimirlo por pantalla.
    public static void calcularValorTeraBytes(String[] tipoDeUnidad, double valor, double[] valoresEquivalentes){
        double[] valorEnBits=new double [6];
        double[] valorEnTeraBytes=new double[6];
        DecimalFormat df = new DecimalFormat("#.###############");//15 decimales
        
        for (int i=0; i<valoresEquivalentes.length; i++) {
            valorEnBits[i]= 1/valoresEquivalentes[i];
            valorEnTeraBytes[i]=valorEnBits[i]*valor*valoresEquivalentes[5];
            String resultadoRedondeado=df.format(valorEnTeraBytes[i]);
            System.out.println("Valor en " + tipoDeUnidad[i] + " = " + resultadoRedondeado);
        }     
    }
}
